// Telegram: @asahiocean

import Foundation

/**
 The task is to implement the Library protocol (you can do that in this file directly).
 - No database or any other storage is required, just store data in memory
 - No any smart search, use String method contains (case sensitive/insensitive - does not matter)
 –   Performance optimizations for listBooksByName and listBooksByAuthor are optional
 */

struct Book {
    let id: String; // unique identifier
    let name: String;
    let author: String;
}

protocol Library {
    /**
     Adds a new book object to the Library.
     - Parameter book: book to add to the Library
     - Returns: false if the book with same id already exists in the Library, true – otherwise.
     */
    func addNewBook(book: Book) -> Bool;
    
    /**
     Deletes the book with the specified id from the Library.
     - Returns: true if the book with same id existed in the Library, false – otherwise.
     */
    func deleteBook(id: String) -> Bool;
    
    /**
     - Returns: 10 book names containing the specified string.
     If there are several books with the same name, author's name is added to book's name in the format "<author> - <book>",
     otherwise returns simply "<book>".
     */
    func listBooksByName(searchString: String) -> Set<String>;
    
    /**
     - Returns: 10 book names whose author contains the specified string,
     result is ordered by authors.
     */
    func listBooksByAuthor(searchString: String) -> [String];
}

// TODO: your implementation goes here
class LibraryImpl: Library {
    
    private var db: [String:Book] = [:] // database
    
    //MARK: - addNewBook -
    
    func addNewBook(book: Book) -> Bool {
        guard db[book.id] != nil else {
            // Provided that the value by key does not exist
            // then it will be added to the database
            db[book.id] = book
            // Then we return the true value
            return true
        }
        // If the value already exists, will returned false
        return false
    }
    
    //MARK: - deleteBook -
    
    func deleteBook(id: String) -> Bool {
        // We proceed from whether the value exists in the database
        guard db[id] == nil else {
            // If the value exists, then method remove it
            db[id] = nil
            // Then we return the true value
            return true
        }
        // If the value does NOT already exist, will returned false
        return false
    }
    
    //MARK: - listBooksByName -
    
    func listBooksByName(searchString: String) -> Set<String> {
        print("➡️ LIST BOOKS BY NAME:", searchString)
        
        var set: Set<String> = [] // set to save results
        
        // Filtered items whose item names contain value 'searchString'
        let filtered = db.filter{ $0.value.name.contains(searchString) }
        
        filtered.forEach({ book in // Iterate through all elements
            
            // Detecting books with the same name
            let coinc = filtered.filter({ $0.value.name == book.value.name }) // coincidences
            
            if coinc.count > 1 {
                // If the title of the book corresponding to the request is not in a only copy,
                // then as a result, its author will be added to the title of the book.
                set.insert("\(book.value.author) - \(book.value.name)") // "<author> - <book>"
                print("‼︎ coincidences:", coinc.compactMap({ $0.value.name + " - " + $0.value.author }).sorted())
            } else {
                set.insert(book.value.name) // "<book>"
                print("► unique:", book.value.name, "-", book.value.author)
            }
            
        })
        let result = Set(set.prefix(10)) // set of 10 books
        print("✅ RESULTS \(result.count):", result, "\n")
        return result
    }
    
    func listBooksByAuthor(searchString: String) -> [String] {
        print("➡️ LIST BOOKS BY AUTHOR:", searchString)
        var array = [String]()
        
        // Copy of a database sorted by key
        let value = db.sorted(by: { $0.key < $1.key }).map({ $0.value })
        
        value.forEach({
            if $0.author.contains(searchString) {
                array.append($0.name)
                print("+", $0.author + " - " + $0.name)
            } else {
                print("-", $0.author + " - " + $0.name)
            }
        })
        
        //MARK: Abridged version without printing information to in console
        /*
         db.filter({ $0.value.author.contains(searchString) })
         .sorted(by: { $0.key < $1.key })
         .map({ $0.value })
         .forEach({ array.append($0.name) })
         */
        
        let result = Array(array.prefix(10)) // top 10
        print("✅ RESULTS \(result.count):", result, "\n")
        return result
    }
    
}

func test(lib: Library) {
    assert(!lib.deleteBook(id: "1"))
    assert(lib.addNewBook(book: Book(id: "1", name: "1", author: "Lex")))
    assert(!lib.addNewBook(book: Book(id: "1", name: "any name because we check id only", author: "any author")))
    assert(lib.deleteBook(id: "1"))
    assert(lib.addNewBook(book: Book(id: "3", name: "Some Book3", author: "Some Author2")))
    assert(lib.addNewBook(book: Book(id: "4", name: "Some Book1", author: "Some Author3")))
    assert(lib.addNewBook(book: Book(id: "2", name: "Some Book2", author: "Some Author2")))
    assert(lib.addNewBook(book: Book(id: "1", name: "Some Book1", author: "Some Author1")))
    assert(lib.addNewBook(book: Book(id: "5", name: "Other Book5", author: "Other Author4")))
    assert(lib.addNewBook(book: Book(id: "6", name: "Other Book6", author: "Other Author4")))
    assert(lib.addNewBook(book: Book(id: "7", name: "Other Book7", author: "Other Author4")))
    assert(lib.addNewBook(book: Book(id: "8", name: "Other Book8", author: "Other Author4")))
    assert(lib.addNewBook(book: Book(id: "9", name: "Other Book9", author: "Other Author4")))
    assert(lib.addNewBook(book: Book(id: "10", name: "Other Book10", author: "Other Author4")))
    assert(lib.addNewBook(book: Book(id: "11", name: "Other Book11", author: "Other Author4")))
    
    var byNames: Set<String> = lib.listBooksByName(searchString: "Book")
    assert(byNames.count == 10)
    
    byNames = lib.listBooksByName(searchString: "Some Book")
    assert(byNames.count == 4)
    assert(byNames.contains("Some Author3 - Some Book1"))
    assert(byNames.contains("Some Book2"))
    assert(byNames.contains("Some Book3"))
    assert(!byNames.contains("Some Book1"))
    assert(byNames.contains("Some Author1 - Some Book1"))
    
    var byAuthor: [String] = lib.listBooksByAuthor(searchString: "Author")
    assert(byAuthor.count == 10)
    
    byAuthor = lib.listBooksByAuthor(searchString: "Some Author")
    assert(byAuthor.count == 4)
    assert(byAuthor[0] == "Some Book1")
    assert(byAuthor[1] == "Some Book2" || byAuthor[1] == "Some Book3")
    assert(byAuthor[2] == "Some Book2" || byAuthor[2] == "Some Book3")
    assert(byAuthor[3] == "Some Book1")
}

test(lib: LibraryImpl())
